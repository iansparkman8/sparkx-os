# GitHub Build Steps

## 1. Create repository

Create a new GitHub repository named:

```text
SparkXFairyOS
```

## 2. Upload files correctly

Upload the **contents** of this package to the repository root.

Correct repo root:

```text
app/
.github/
scripts/
build.gradle.kts
settings.gradle.kts
gradle.properties
START_HERE.md
```

Incorrect repo root:

```text
SparkXFairyOS_Build_Test_One_v1/app/
SparkXFairyOS_Build_Test_One_v1/build.gradle.kts
```

## 3. Commit to main

Commit the files to `main`.

## 4. Run workflow

Go to:

```text
Actions → SparkX Fairy OS Build Test One → Run workflow
```

## 5. Download APK

After success, open the workflow run and download:

```text
SparkXFairyOS-build-test-one-debug-apk
```

Unzip it and install the debug APK on Android.

## 6. If build fails

Copy the first red error block, including file path and line number, and paste it into ChatGPT.

Do not run another design pass until the compiler is clean.
