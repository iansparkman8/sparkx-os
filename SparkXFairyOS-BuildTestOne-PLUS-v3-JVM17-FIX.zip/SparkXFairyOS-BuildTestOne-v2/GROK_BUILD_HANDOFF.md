# Grok + ChatGPT Build Handoff — SparkX Fairy OS

Grok, here is the current app package direction.

## Goal

Build a native Android Kotlin/Jetpack Compose app for Spark Baby: a living holographic fairy companion that can float over the Android screen, listen through Android speech recognition, and accept safe user-taught lessons/upgrades.

## What is implemented now

- Compose home screen with Spark Baby avatar, orb, quick actions, command input.
- Teach & Grow lab for saved lessons, code suggestions, behavior upgrades, visual polish ideas, and review/approval states.
- Android floating overlay service using `WindowManager.TYPE_APPLICATION_OVERLAY`.
- Draggable custom Canvas overlay bubble drawn in native Android View code.
- Foreground service notification with Open/Hide actions.
- Permission wizard for overlay, microphone, and notification permission.
- SpeechRecognizer command loop for basic commands: float/overlay, teach/grow/learn, voice/listen/talk, reminder/alarm.

## Safety boundary

Teach & Grow does not execute pasted code, load remote code, or silently control the phone. It stores ideas for review. That is intentional for build/test one.

## Files to inspect first

- `app/src/main/java/com/sparkx/fairyos/MainActivity.kt`
- `app/src/main/java/com/sparkx/fairyos/overlay/SparkOverlayService.kt`
- `app/src/main/java/com/sparkx/fairyos/overlay/SparkOverlayBubbleView.kt`
- `app/src/main/java/com/sparkx/fairyos/ui/screens/SparkHomeScreen.kt`
- `app/src/main/AndroidManifest.xml`
- `.github/workflows/build-test-one.yml`

## Build command

```bash
gradle :app:assembleDebug --no-daemon --stacktrace
```

## If the build fails

Fix the first compiler error only, rebuild, then repeat. Do not rewrite the whole architecture unless the failure proves the current path is wrong.
