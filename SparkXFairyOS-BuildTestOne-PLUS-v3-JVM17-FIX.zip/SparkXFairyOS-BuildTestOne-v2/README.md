# SparkX Fairy OS — Build/Test One Plus

SparkX Fairy OS is a native Android prototype for a living holographic AI companion named Spark Baby.

This package is scoped to get a real debug APK build and a real-device test loop.

## Core features

- Kotlin + Jetpack Compose + Material 3
- Holographic Spark Baby home screen
- Safe Teach & Grow upgrade lab
- Permission wizard for overlay, voice, and notifications
- Native Android speech recognition command loop
- Foreground overlay service
- Draggable floating Spark Baby bubble over other apps
- GitHub Actions APK build workflow

## Build

Use GitHub Actions or locally with Android SDK installed:

```bash
gradle :app:assembleDebug --no-daemon --stacktrace
```

## APK output

```text
app/build/outputs/apk/debug/app-debug.apk
```

## Safety model

The Upgrade Lab stores and reviews ideas. It does not execute pasted code, load remote code, exfiltrate data, or secretly control the phone.
