# SparkX Fairy OS — Build/Test One Plus

This is the next serious build package for Spark Baby.

## What changed in this package

- Keeps the original holographic Spark Baby home screen.
- Keeps Teach & Grow safe upgrade capture.
- Adds a real Android floating overlay service.
- Adds a permission wizard for Float, Voice, and Notifications.
- Adds native Android speech recognition for simple natural commands.
- Adds a draggable floating Spark Baby bubble over other apps.
- Keeps the Upgrade Lab safe: ideas are saved and reviewed, not executed.

## Build from GitHub for free

1. Create a new GitHub repository.
2. Upload every file/folder from this package to the repository root.
3. Open the repository on GitHub.
4. Tap **Actions**.
5. Select **SparkX Fairy OS Build Test One Plus**.
6. Tap **Run workflow**.
7. Download the APK from the workflow artifact when it finishes.

## Local build command

If Android Studio or Android SDK + Gradle is installed:

```bash
gradle :app:assembleDebug --no-daemon --stacktrace
```

APK output:

```text
app/build/outputs/apk/debug/app-debug.apk
```

## First real-phone test

1. Install the debug APK.
2. Open SparkX Fairy OS.
3. Tap **Allow Notice** if Android asks.
4. Tap **Allow Voice** if you want speech input.
5. Tap **Allow Float** and enable overlay permission for SparkX Fairy OS.
6. Return to the app and tap **Float On**.
7. Drag Spark Baby around your phone screen.
8. Tap the bubble to expand/collapse it.
9. Tap **Teach & Grow** and save a lesson, code idea, behavior, or visual polish note.

## Honest status

This is a build/test-one-plus prototype, not the final sellable app yet. It now has the real Android structure for overlay + voice + teaching, but it still needs APK compile validation on GitHub Actions or Android Studio, then device testing.
