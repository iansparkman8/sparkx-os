package com.sparkx.fairyos

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.platform.LocalContext
import androidx.lifecycle.viewmodel.compose.viewModel
import com.sparkx.fairyos.domain.FairyMood
import com.sparkx.fairyos.overlay.SparkOverlayService
import com.sparkx.fairyos.ui.screens.SparkHomeScreen
import com.sparkx.fairyos.ui.screens.teach.TeachGrowScreen
import com.sparkx.fairyos.ui.viewmodel.UpgradeLabViewModel

private enum class AppScreen {
    HOME,
    TEACH
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme {
                SparkXApp()
            }
        }
    }
}

@Composable
private fun SparkXApp() {
    val context = LocalContext.current
    val upgradeViewModel: UpgradeLabViewModel = viewModel()
    val labMood by upgradeViewModel.currentFairyMood.collectAsState()
    var currentScreen by remember { mutableStateOf(AppScreen.HOME) }
    var homeMood by remember { mutableStateOf(FairyMood.IDLE) }
    var statusText by remember { mutableStateOf("Ready. Grant float + voice when you want Spark Baby alive over your phone.") }
    var permissionRefresh by remember { mutableIntStateOf(0) }

    fun hasPermission(permission: String): Boolean {
        return if (Build.VERSION.SDK_INT < Build.VERSION_CODES.M) {
            true
        } else {
            context.checkSelfPermission(permission) == PackageManager.PERMISSION_GRANTED
        }
    }

    fun overlayReady(): Boolean {
        permissionRefresh
        return Settings.canDrawOverlays(context)
    }

    fun micReady(): Boolean {
        permissionRefresh
        return hasPermission(Manifest.permission.RECORD_AUDIO)
    }

    fun notificationsReady(): Boolean {
        permissionRefresh
        return Build.VERSION.SDK_INT < Build.VERSION_CODES.TIRAMISU || hasPermission(Manifest.permission.POST_NOTIFICATIONS)
    }

    val overlaySettingsLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.StartActivityForResult()
    ) {
        permissionRefresh++
        if (Settings.canDrawOverlays(context)) {
            SparkOverlayService.start(context)
            homeMood = FairyMood.HAPPY
            statusText = "Spark Baby is now floating. Drag the bubble anywhere and tap it to expand."
        } else {
            homeMood = FairyMood.ALERT
            statusText = "Floating still needs permission. Tap Allow Float when you are ready."
        }
    }

    val micPermissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { granted ->
        permissionRefresh++
        homeMood = if (granted) FairyMood.LISTENING else FairyMood.ALERT
        statusText = if (granted) {
            "Voice is ready. Tap the heart/mic button and talk to Spark Baby."
        } else {
            "Voice permission was not granted. Typing still works."
        }
    }

    val notificationPermissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { granted ->
        permissionRefresh++
        statusText = if (granted) {
            "Notifications are ready, so Android can keep the floating companion visible."
        } else {
            "Notifications were not granted. The app can still run, but Android may hide overlay status."
        }
        homeMood = if (granted) FairyMood.HAPPY else FairyMood.ALERT
    }

    val speechRecognizer = remember(context) {
        if (SpeechRecognizer.isRecognitionAvailable(context)) {
            SpeechRecognizer.createSpeechRecognizer(context)
        } else {
            null
        }
    }

    DisposableEffect(speechRecognizer) {
        onDispose { speechRecognizer?.destroy() }
    }

    fun startOverlayFlow() {
        if (overlayReady()) {
            SparkOverlayService.start(context)
            homeMood = FairyMood.HAPPY
            statusText = "Spark Baby is floating live. Drag her anywhere. Tap her bubble to expand."
        } else {
            statusText = "Android will open the overlay permission screen. Enable SparkX Fairy OS, then come back."
            overlaySettingsLauncher.launch(SparkOverlayService.overlaySettingsIntent(context))
        }
    }

    fun requestMicFlow() {
        if (micReady()) {
            homeMood = FairyMood.HAPPY
            statusText = "Voice is already ready. Tap the heart/mic button to start listening."
        } else {
            micPermissionLauncher.launch(Manifest.permission.RECORD_AUDIO)
        }
    }

    fun requestNotificationFlow() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU && !notificationsReady()) {
            notificationPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
        } else {
            homeMood = FairyMood.HAPPY
            statusText = "Notification support is ready."
        }
    }

    fun handleCommand(command: String) {
        val cleaned = command.trim()
        if (cleaned.isBlank()) return
        val lower = cleaned.lowercase()
        when {
            "float" in lower || "overlay" in lower -> startOverlayFlow()
            "teach" in lower || "grow" in lower || "learn" in lower -> {
                currentScreen = AppScreen.TEACH
                homeMood = FairyMood.THINKING
                statusText = "Teach & Grow opened. Save lessons, behaviors, code ideas, and visual polish safely."
            }
            "voice" in lower || "listen" in lower || "talk" in lower -> requestMicFlow()
            "remind" in lower || "alarm" in lower -> {
                requestNotificationFlow()
                homeMood = FairyMood.ALERT
                statusText = "Reminder shell is staged for build/test one. Notification permission is the first step."
            }
            else -> {
                homeMood = FairyMood.THINKING
                statusText = "Spark Baby heard: “$cleaned”. For build/test one this is kept local and safe."
            }
        }
    }

    fun startVoiceFlow() {
        if (!micReady()) {
            micPermissionLauncher.launch(Manifest.permission.RECORD_AUDIO)
            return
        }
        val recognizer = speechRecognizer
        if (recognizer == null) {
            homeMood = FairyMood.ALERT
            statusText = "This Android device does not expose speech recognition right now. Typing still works."
            return
        }

        recognizer.setRecognitionListener(object : RecognitionListener {
            override fun onReadyForSpeech(params: Bundle?) {
                homeMood = FairyMood.LISTENING
                statusText = "Listening… speak naturally to Spark Baby."
            }

            override fun onBeginningOfSpeech() {
                homeMood = FairyMood.LISTENING
                statusText = "Spark Baby hears you."
            }

            override fun onRmsChanged(rmsdB: Float) = Unit
            override fun onBufferReceived(buffer: ByteArray?) = Unit
            override fun onEndOfSpeech() {
                homeMood = FairyMood.THINKING
                statusText = "Thinking…"
            }

            override fun onError(error: Int) {
                homeMood = FairyMood.ALERT
                statusText = "Voice did not catch that. Try again or type it in."
            }

            override fun onResults(results: Bundle?) {
                val heard = results
                    ?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                    ?.firstOrNull()
                    .orEmpty()
                if (heard.isBlank()) {
                    homeMood = FairyMood.ALERT
                    statusText = "Voice returned empty. Try again."
                } else {
                    handleCommand(heard)
                }
            }

            override fun onPartialResults(partialResults: Bundle?) {
                val partial = partialResults
                    ?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                    ?.firstOrNull()
                    .orEmpty()
                if (partial.isNotBlank()) {
                    statusText = "Hearing: $partial"
                }
            }

            override fun onEvent(eventType: Int, params: Bundle?) = Unit
        })

        val listenIntent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
            putExtra(RecognizerIntent.EXTRA_PROMPT, "Tell Spark Baby what to do")
        }
        homeMood = FairyMood.LISTENING
        statusText = "Opening voice listener…"
        recognizer.startListening(listenIntent)
    }

    when (currentScreen) {
        AppScreen.HOME -> SparkHomeScreen(
            fairyMood = homeMood,
            statusText = statusText,
            overlayReady = overlayReady(),
            micReady = micReady(),
            notificationReady = notificationsReady(),
            onChatClick = {
                homeMood = FairyMood.LISTENING
                statusText = "Chat mode staged. Type below or tap voice."
            },
            onTeachClick = { currentScreen = AppScreen.TEACH },
            onReminderClick = { requestNotificationFlow() },
            onMelodyClick = {
                homeMood = FairyMood.HAPPY
                statusText = "Melody mood active. Build/test one animates the fairy; audio comes next."
            },
            onMemoriesClick = {
                homeMood = FairyMood.THINKING
                statusText = "Memory explorer shell is staged. Saved Teach & Grow ideas are available now."
            },
            onOverlayClick = { startOverlayFlow() },
            onMicPermissionClick = { requestMicFlow() },
            onNotificationClick = { requestNotificationFlow() },
            onCommandSubmit = { handleCommand(it) },
            onMicClick = { startVoiceFlow() },
            onTypingStateShift = { isTyping ->
                homeMood = if (isTyping) FairyMood.LISTENING else FairyMood.IDLE
            }
        )

        AppScreen.TEACH -> TeachGrowScreen(
            viewModel = upgradeViewModel,
            onBack = {
                homeMood = labMood
                statusText = "Back home. Spark Baby kept the Teach & Grow ideas safe in this session."
                currentScreen = AppScreen.HOME
            }
        )
    }
}
