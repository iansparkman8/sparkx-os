package com.sparkx.fairyos.domain.upgrade

enum class UpgradeCategory {
    CODE_UPDATE,
    VISUAL_UPGRADE,
    BEHAVIOR_UPGRADE,
    PROMPT_UPGRADE,
    BUG_FIX,
    FEATURE_REQUEST,
    LESSON
}

enum class UpgradeRiskLevel {
    LOW,
    MEDIUM,
    HIGH,
    UNKNOWN
}

enum class UpgradeStatus {
    SAVED,
    NEEDS_REVIEW,
    APPROVED,
    REJECTED,
    EXPORTED
}

data class UpgradeItem(
    val id: Long,
    val title: String,
    val targetFile: String? = null,
    val language: String? = null,
    val content: String,
    val category: UpgradeCategory,
    val reason: String? = null,
    val riskLevel: UpgradeRiskLevel = UpgradeRiskLevel.UNKNOWN,
    val status: UpgradeStatus = UpgradeStatus.NEEDS_REVIEW,
    val summary: String? = null,
    val warnings: String? = null
)
