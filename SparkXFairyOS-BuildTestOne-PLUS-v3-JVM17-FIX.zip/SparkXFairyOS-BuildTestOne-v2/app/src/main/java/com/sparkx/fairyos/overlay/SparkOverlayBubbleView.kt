package com.sparkx.fairyos.overlay

import android.content.Context
import android.graphics.BlurMaskFilter
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RadialGradient
import android.graphics.RectF
import android.graphics.Shader
import android.os.SystemClock
import android.util.AttributeSet
import android.view.View
import kotlin.math.cos
import kotlin.math.min
import kotlin.math.sin

class SparkOverlayBubbleView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null
) : View(context, attrs) {
    var onOpenRequested: (() -> Unit)? = null
    private var expanded = false
    private val startTime = SystemClock.uptimeMillis()

    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val strokePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
    }
    private val textPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE
        textSize = 28f
        typeface = android.graphics.Typeface.create(android.graphics.Typeface.DEFAULT, android.graphics.Typeface.BOLD)
    }
    private val smallTextPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.argb(220, 190, 255, 246)
        textSize = 20f
        typeface = android.graphics.Typeface.create(android.graphics.Typeface.DEFAULT, android.graphics.Typeface.BOLD)
    }
    private val wingPath = Path()
    private val bodyPath = Path()
    private val crownPath = Path()

    init {
        setLayerType(LAYER_TYPE_SOFTWARE, null)
        isClickable = true
        importantForAccessibility = IMPORTANT_FOR_ACCESSIBILITY_YES
    }

    override fun onMeasure(widthMeasureSpec: Int, heightMeasureSpec: Int) {
        val width = if (expanded) 310 else 178
        val height = if (expanded) 230 else 178
        setMeasuredDimension(width, height)
    }

    override fun performClick(): Boolean {
        super.performClick()
        return true
    }

    fun toggleExpanded() {
        expanded = !expanded
        requestLayout()
        invalidate()
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val elapsed = (SystemClock.uptimeMillis() - startTime) / 1000f
        val pulse = 0.88f + 0.12f * sin((elapsed * 2.2f).toDouble()).toFloat()
        val bob = sin((elapsed * 1.8f).toDouble()).toFloat() * 5f
        val cx = width * 0.5f
        val cy = if (expanded) height * 0.43f + bob else height * 0.50f + bob
        val radius = min(width, height) * if (expanded) 0.34f else 0.43f

        drawOuterGlow(canvas, cx, cy, radius, pulse)
        drawGlassBubble(canvas, cx, cy, radius, pulse)
        drawFairy(canvas, cx, cy, radius, pulse, elapsed)
        drawParticles(canvas, cx, cy, radius, elapsed)

        if (expanded) {
            drawExpandedPanel(canvas)
        }
        postInvalidateDelayed(16L)
    }

    private fun drawOuterGlow(canvas: Canvas, cx: Float, cy: Float, radius: Float, pulse: Float) {
        paint.style = Paint.Style.FILL
        paint.maskFilter = BlurMaskFilter(24f * pulse, BlurMaskFilter.Blur.NORMAL)
        paint.shader = RadialGradient(
            cx,
            cy,
            radius * 1.32f,
            intArrayOf(Color.argb(165, 0, 245, 212), Color.argb(65, 157, 78, 221), Color.TRANSPARENT),
            floatArrayOf(0f, 0.5f, 1f),
            Shader.TileMode.CLAMP
        )
        canvas.drawCircle(cx, cy, radius * 1.13f, paint)
        paint.maskFilter = null
        paint.shader = null
    }

    private fun drawGlassBubble(canvas: Canvas, cx: Float, cy: Float, radius: Float, pulse: Float) {
        paint.style = Paint.Style.FILL
        paint.shader = RadialGradient(
            cx - radius * 0.35f,
            cy - radius * 0.45f,
            radius * 1.4f,
            intArrayOf(Color.argb(95, 255, 255, 255), Color.argb(45, 0, 245, 212), Color.argb(20, 157, 78, 221)),
            floatArrayOf(0f, 0.52f, 1f),
            Shader.TileMode.CLAMP
        )
        canvas.drawCircle(cx, cy, radius, paint)
        paint.shader = null

        strokePaint.strokeWidth = 3.2f
        strokePaint.shader = LinearGradient(
            cx - radius,
            cy - radius,
            cx + radius,
            cy + radius,
            intArrayOf(Color.WHITE, Color.argb(230, 0, 245, 212), Color.argb(220, 255, 0, 127)),
            null,
            Shader.TileMode.CLAMP
        )
        canvas.drawCircle(cx, cy, radius, strokePaint)
        strokePaint.shader = null

        paint.style = Paint.Style.STROKE
        paint.strokeWidth = 4f
        paint.color = Color.argb(160, 255, 255, 255)
        val glint = RectF(cx - radius * 0.62f, cy - radius * 0.72f, cx + radius * 0.18f, cy + radius * 0.12f)
        canvas.drawArc(glint, 205f, 70f, false, paint)
        paint.style = Paint.Style.FILL
    }

    private fun drawFairy(canvas: Canvas, cx: Float, cy: Float, radius: Float, pulse: Float, elapsed: Float) {
        val base = Color.rgb(0, 245, 212)
        val magenta = Color.rgb(255, 0, 127)
        val gold = Color.rgb(255, 215, 0)
        val wingFlap = 0.86f + 0.12f * sin((elapsed * 10f).toDouble()).toFloat()
        val headR = radius * 0.22f
        val headY = cy - radius * 0.17f
        val bodyY = headY + headR * 0.85f

        wingPath.reset()
        wingPath.moveTo(cx - radius * 0.06f, bodyY)
        wingPath.cubicTo(cx - radius * 0.66f * wingFlap, cy - radius * 0.47f, cx - radius * 0.78f, cy + radius * 0.05f, cx - radius * 0.05f, cy + radius * 0.22f)
        wingPath.close()
        paint.shader = LinearGradient(cx - radius, cy - radius, cx, cy + radius, Color.argb(160, 0, 245, 212), Color.argb(15, 255, 255, 255), Shader.TileMode.CLAMP)
        canvas.drawPath(wingPath, paint)
        strokePaint.color = Color.argb(170, 182, 255, 248)
        strokePaint.strokeWidth = 1.6f
        canvas.drawPath(wingPath, strokePaint)

        wingPath.reset()
        wingPath.moveTo(cx + radius * 0.06f, bodyY)
        wingPath.cubicTo(cx + radius * 0.66f * wingFlap, cy - radius * 0.47f, cx + radius * 0.78f, cy + radius * 0.05f, cx + radius * 0.05f, cy + radius * 0.22f)
        wingPath.close()
        paint.shader = LinearGradient(cx, cy - radius, cx + radius, cy + radius, Color.argb(150, 157, 78, 221), Color.argb(15, 255, 255, 255), Shader.TileMode.CLAMP)
        canvas.drawPath(wingPath, paint)
        canvas.drawPath(wingPath, strokePaint)
        paint.shader = null

        bodyPath.reset()
        bodyPath.moveTo(cx, bodyY)
        bodyPath.cubicTo(cx - radius * 0.2f, cy + radius * 0.1f, cx - radius * 0.12f, cy + radius * 0.44f, cx, cy + radius * 0.55f)
        bodyPath.cubicTo(cx + radius * 0.12f, cy + radius * 0.44f, cx + radius * 0.2f, cy + radius * 0.1f, cx, bodyY)
        paint.shader = LinearGradient(cx, bodyY, cx, cy + radius * 0.55f, Color.WHITE, Color.argb(145, 0, 245, 212), Shader.TileMode.CLAMP)
        canvas.drawPath(bodyPath, paint)
        paint.shader = null

        paint.shader = RadialGradient(cx, bodyY + radius * 0.1f, radius * 0.22f * pulse, intArrayOf(Color.WHITE, Color.argb(220, 0, 245, 212), Color.TRANSPARENT), null, Shader.TileMode.CLAMP)
        canvas.drawCircle(cx, bodyY + radius * 0.1f, radius * 0.18f * pulse, paint)
        paint.shader = null

        paint.shader = RadialGradient(cx - headR * 0.35f, headY - headR * 0.45f, headR * 1.4f, Color.WHITE, Color.argb(210, 220, 196, 255), Shader.TileMode.CLAMP)
        canvas.drawCircle(cx, headY, headR, paint)
        paint.shader = null

        paint.color = Color.argb(245, 0, 245, 212)
        canvas.drawCircle(cx - headR * 0.38f, headY + headR * 0.03f, headR * 0.15f, paint)
        canvas.drawCircle(cx + headR * 0.38f, headY + headR * 0.03f, headR * 0.15f, paint)
        paint.color = Color.WHITE
        canvas.drawCircle(cx - headR * 0.43f, headY - headR * 0.02f, 2.2f, paint)
        canvas.drawCircle(cx + headR * 0.33f, headY - headR * 0.02f, 2.2f, paint)

        strokePaint.strokeWidth = 2f
        strokePaint.color = Color.argb(220, 157, 78, 221)
        val mouth = RectF(cx - headR * 0.18f, headY + headR * 0.33f, cx + headR * 0.18f, headY + headR * 0.52f)
        canvas.drawArc(mouth, 0f, 180f, false, strokePaint)

        crownPath.reset()
        val crownY = headY - headR * 0.92f
        crownPath.moveTo(cx - headR * 0.6f, crownY + headR * 0.35f)
        crownPath.lineTo(cx - headR * 0.35f, crownY - headR * 0.1f)
        crownPath.lineTo(cx - headR * 0.12f, crownY + headR * 0.25f)
        crownPath.lineTo(cx, crownY - headR * 0.25f * pulse)
        crownPath.lineTo(cx + headR * 0.12f, crownY + headR * 0.25f)
        crownPath.lineTo(cx + headR * 0.35f, crownY - headR * 0.1f)
        crownPath.lineTo(cx + headR * 0.6f, crownY + headR * 0.35f)
        crownPath.close()
        paint.shader = LinearGradient(cx, crownY - headR * 0.3f, cx, crownY + headR * 0.4f, gold, Color.WHITE, Shader.TileMode.CLAMP)
        canvas.drawPath(crownPath, paint)
        paint.shader = null
        strokePaint.color = Color.argb(230, 0, 245, 212)
        strokePaint.strokeWidth = 1.5f
        canvas.drawPath(crownPath, strokePaint)
    }

    private fun drawParticles(canvas: Canvas, cx: Float, cy: Float, radius: Float, elapsed: Float) {
        for (i in 0 until 10) {
            val angle = elapsed * 1.2f + i * 0.628f
            val orbit = radius * (0.78f + (i % 3) * 0.08f)
            val x = cx + cos(angle.toDouble()).toFloat() * orbit
            val y = cy + sin(angle.toDouble()).toFloat() * orbit * 0.62f
            paint.color = if (i % 2 == 0) Color.argb(215, 0, 245, 212) else Color.argb(200, 255, 0, 127)
            canvas.drawCircle(x, y, if (i % 2 == 0) 3.2f else 2.0f, paint)
        }
    }

    private fun drawExpandedPanel(canvas: Canvas) {
        val top = height - 65f
        val panel = RectF(18f, top, width - 18f, height - 14f)
        paint.color = Color.argb(185, 11, 7, 24)
        canvas.drawRoundRect(panel, 24f, 24f, paint)
        strokePaint.color = Color.argb(180, 0, 245, 212)
        strokePaint.strokeWidth = 2f
        canvas.drawRoundRect(panel, 24f, 24f, strokePaint)
        canvas.drawText("Spark Baby", 42f, top + 32f, textPaint)
        canvas.drawText("tap twice in app for voice + teaching", 42f, top + 54f, smallTextPaint)
    }
}
