package com.sparkx.fairyos.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.GenericShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.sparkx.fairyos.domain.upgrade.SparkColors

@Composable
fun CommandInputBar(
    onSubmit: (String) -> Unit,
    onMicClick: () -> Unit,
    modifier: Modifier = Modifier,
    onTextChanged: (String) -> Unit = {}
) {
    var textState by remember { mutableStateOf("") }
    val beveledCrystalShape = remember {
        GenericShape { size, _ ->
            val bevel = 22f
            moveTo(bevel, 0f)
            lineTo(size.width - bevel, 0f)
            lineTo(size.width, size.height / 2f)
            lineTo(size.width - bevel, size.height)
            lineTo(bevel, size.height)
            lineTo(0f, size.height / 2f)
            close()
        }
    }

    Box(
        modifier = modifier
            .fillMaxWidth()
            .height(64.dp)
            .background(
                brush = Brush.verticalGradient(
                    listOf(SparkColors.GlassBg, SparkColors.GlowPurple.copy(alpha = 0.15f))
                ),
                shape = beveledCrystalShape
            )
            .border(
                width = 1.8.dp,
                brush = Brush.horizontalGradient(
                    listOf(SparkColors.NeonCyan, SparkColors.VibrantMagenta, SparkColors.NeonCyan)
                ),
                shape = beveledCrystalShape
            )
            .padding(horizontal = 24.dp),
        contentAlignment = Alignment.Center
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically
        ) {
            BasicTextField(
                value = textState,
                onValueChange = { newValue ->
                    textState = newValue
                    onTextChanged(newValue)
                },
                textStyle = TextStyle(color = Color.White, fontSize = 15.sp),
                modifier = Modifier.weight(1f),
                decorationBox = { innerTextField ->
                    if (textState.isEmpty()) {
                        Text(
                            text = "Tell Spark Baby...",
                            color = Color.White.copy(alpha = 0.45f),
                            fontSize = 15.sp
                        )
                    }
                    innerTextField()
                }
            )

            IconButton(onClick = onMicClick) {
                Text(
                    text = "♡",
                    color = Color.White,
                    fontSize = 22.sp,
                    fontWeight = FontWeight.Bold
                )
            }
            if (textState.isNotEmpty()) {
                IconButton(
                    onClick = {
                        val submitted = textState
                        textState = ""
                        onTextChanged("")
                        onSubmit(submitted)
                    }
                ) {
                    Text(
                        text = "➤",
                        color = SparkColors.NeonCyan,
                        fontSize = 22.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }
    }
}
