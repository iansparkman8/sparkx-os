package com.sparkx.fairyos.ui.components

import androidx.compose.animation.core.EaseInOutSine
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.unit.dp
import com.sparkx.fairyos.domain.FairyMood
import com.sparkx.fairyos.domain.upgrade.SparkColors
import kotlin.random.Random

@Composable
fun HoloBackground(
    modifier: Modifier = Modifier,
    mood: FairyMood = FairyMood.IDLE,
    content: @Composable () -> Unit
) {
    val transition = rememberInfiniteTransition(label = "HoloBackgroundSystem")
    val pulseAlpha by transition.animateFloat(
        initialValue = 0.3f,
        targetValue = 0.8f,
        animationSpec = infiniteRepeatable(
            animation = tween(2500, easing = EaseInOutSine),
            repeatMode = RepeatMode.Reverse
        ),
        label = "PulseAlpha"
    )
    val driftOffset by transition.animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(
            animation = tween(15000, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "DriftOffset"
    )

    val nearParticles = remember {
        List(20) { BackgroundParticle(Random.nextFloat(), Random.nextFloat(), Random.nextFloat() * 3f + 3f) }
    }
    val farDustParticles = remember {
        List(11) { BackgroundParticle(Random.nextFloat(), Random.nextFloat(), Random.nextFloat() * 1.5f + 1f) }
    }

    val tintMoodColor = when (mood) {
        FairyMood.IDLE -> SparkColors.NeonCyan
        FairyMood.HAPPY -> SparkColors.VibrantMagenta
        FairyMood.THINKING -> SparkColors.GlowPurple
        FairyMood.LISTENING -> SparkColors.NeonCyan
        FairyMood.ALERT -> SparkColors.GoldEnergy
        FairyMood.SLEEPY -> SparkColors.SoftLavender
    }

    Box(modifier = modifier.fillMaxSize()) {
        Canvas(modifier = Modifier.fillMaxSize()) {
            drawRect(brush = Brush.verticalGradient(listOf(SparkColors.DeepVoid, SparkColors.NebulaPurple)))

            val gridSpacing = 44.dp.toPx().coerceAtLeast(1f)
            for (x in 0..size.width.toInt() step gridSpacing.toInt()) {
                drawLine(
                    color = SparkColors.GlowPurple.copy(alpha = 0.05f),
                    start = Offset(x.toFloat(), 0f),
                    end = Offset(x.toFloat(), size.height)
                )
            }
            for (y in 0..size.height.toInt() step gridSpacing.toInt()) {
                drawLine(
                    color = SparkColors.GlowPurple.copy(alpha = 0.05f),
                    start = Offset(0f, y.toFloat()),
                    end = Offset(size.width, y.toFloat())
                )
            }

            farDustParticles.forEach { particle ->
                drawCircle(
                    color = tintMoodColor.copy(alpha = particle.alphaBase * 0.15f),
                    radius = particle.radius,
                    center = Offset(
                        x = particle.x * size.width,
                        y = ((particle.y + driftOffset * 0.2f) % 1f) * size.height
                    )
                )
            }

            nearParticles.forEach { particle ->
                drawCircle(
                    color = tintMoodColor.copy(alpha = particle.alphaBase * pulseAlpha * 0.5f),
                    radius = particle.radius,
                    center = Offset(
                        x = particle.x * size.width,
                        y = ((particle.y + driftOffset * 0.4f) % 1f) * size.height
                    )
                )
            }
        }
        content()
    }
}

data class BackgroundParticle(
    val x: Float,
    val y: Float,
    val radius: Float,
    val alphaBase: Float = Random.nextFloat()
)
