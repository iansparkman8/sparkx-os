package com.sparkx.fairyos.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.sparkx.fairyos.domain.upgrade.SparkColors

@Composable
fun HoloCodeBox(
    value: String,
    onValueChange: (String) -> Unit,
    placeholder: String
) {
    OutlinedTextField(
        value = value,
        onValueChange = onValueChange,
        placeholder = { Text(placeholder, color = Color.White.copy(alpha = 0.25f)) },
        textStyle = TextStyle(
            color = SparkColors.NeonCyan,
            fontFamily = FontFamily.Monospace,
            fontSize = 13.sp
        ),
        modifier = Modifier
            .fillMaxWidth()
            .height(170.dp)
            .background(SparkColors.TerminalBlack.copy(alpha = 0.85f), RoundedCornerShape(14.dp))
            .border(1.dp, SparkColors.GlowPurple.copy(alpha = 0.4f), RoundedCornerShape(14.dp)),
        shape = RoundedCornerShape(14.dp),
        colors = OutlinedTextFieldDefaults.colors(
            focusedBorderColor = SparkColors.NeonCyan,
            unfocusedBorderColor = Color.Transparent,
            focusedContainerColor = Color.Transparent,
            unfocusedContainerColor = Color.Transparent,
            cursorColor = SparkColors.NeonCyan
        )
    )
}
