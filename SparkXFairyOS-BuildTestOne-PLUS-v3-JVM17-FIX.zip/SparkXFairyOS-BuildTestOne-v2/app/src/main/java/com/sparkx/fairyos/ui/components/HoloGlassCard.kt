package com.sparkx.fairyos.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import com.sparkx.fairyos.domain.upgrade.SparkColors

@Composable
fun HoloGlassCard(
    modifier: Modifier = Modifier,
    highlightColor: Color = SparkColors.NeonCyan,
    content: @Composable () -> Unit
) {
    Box(
        modifier = modifier
            .background(SparkColors.GlassBg, RoundedCornerShape(18.dp))
            .border(1.dp, highlightColor.copy(alpha = 0.35f), RoundedCornerShape(18.dp))
            .padding(16.dp)
    ) {
        content()
    }
}
