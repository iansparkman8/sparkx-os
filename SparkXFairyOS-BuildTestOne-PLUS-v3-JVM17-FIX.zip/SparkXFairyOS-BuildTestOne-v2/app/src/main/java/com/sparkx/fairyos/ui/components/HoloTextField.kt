package com.sparkx.fairyos.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.material3.TextField
import androidx.compose.material3.TextFieldDefaults
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.sparkx.fairyos.domain.upgrade.SparkColors

@Composable
fun HoloTextField(
    value: String,
    onValueChange: (String) -> Unit,
    label: String,
    modifier: Modifier = Modifier,
    placeholder: String = "",
    singleLine: Boolean = false,
    minLines: Int = 1,
    maxLines: Int = 6,
    leadingSymbol: String? = null
) {
    Column(modifier = modifier.fillMaxWidth()) {
        Text(
            text = label.uppercase(),
            color = SparkColors.NeonCyan,
            fontSize = 11.sp,
            fontWeight = FontWeight.Bold,
            modifier = Modifier.padding(start = 4.dp, bottom = 6.dp)
        )
        TextField(
            value = value,
            onValueChange = onValueChange,
            placeholder = {
                if (placeholder.isNotEmpty()) {
                    Text(placeholder, color = Color.White.copy(alpha = 0.3f))
                }
            },
            leadingIcon = leadingSymbol?.let { symbol ->
                { Text(text = symbol, color = SparkColors.NeonCyan, fontSize = 16.sp, fontWeight = FontWeight.Bold) }
            },
            singleLine = singleLine,
            minLines = minLines,
            maxLines = maxLines,
            textStyle = TextStyle(color = Color.White, fontSize = 14.sp),
            colors = TextFieldDefaults.colors(
                focusedContainerColor = SparkColors.GlassBg,
                unfocusedContainerColor = SparkColors.GlassBg,
                focusedIndicatorColor = Color.Transparent,
                unfocusedIndicatorColor = Color.Transparent,
                cursorColor = SparkColors.NeonCyan
            ),
            modifier = Modifier
                .fillMaxWidth()
                .background(SparkColors.GlassBg, RoundedCornerShape(16.dp))
                .border(1.dp, SparkColors.GlassBorder, RoundedCornerShape(16.dp))
        )
    }
}
