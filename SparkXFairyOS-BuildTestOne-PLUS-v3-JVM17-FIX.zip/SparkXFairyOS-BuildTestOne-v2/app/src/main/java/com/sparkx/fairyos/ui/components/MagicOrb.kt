package com.sparkx.fairyos.ui.components

import androidx.compose.animation.core.EaseInOutSine
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.size
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.withTransform
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.sparkx.fairyos.domain.upgrade.SparkColors

@Composable
fun MagicOrb(
    modifier: Modifier = Modifier,
    orbSize: Dp = 100.dp
) {
    val transition = rememberInfiniteTransition(label = "OrbPlasmaCore")
    val rotation by transition.animateFloat(
        initialValue = 0f,
        targetValue = 360f,
        animationSpec = infiniteRepeatable(animation = tween(8000, easing = LinearEasing)),
        label = "Rotate"
    )
    val pulseScale by transition.animateFloat(
        initialValue = 0.92f,
        targetValue = 1.08f,
        animationSpec = infiniteRepeatable(
            animation = tween(2000, easing = EaseInOutSine),
            repeatMode = RepeatMode.Reverse
        ),
        label = "Pulse"
    )
    val pedestalPath = remember { Path() }

    Canvas(modifier = modifier.size(orbSize)) {
        val radius = size.width * 0.28f
        val center = Offset(size.width / 2f, size.height * 0.34f)
        val pedestalBottom = size.height * 0.92f
        val baseY = center.y + radius - 1.dp.toPx()
        val midY = (baseY + pedestalBottom) / 2f
        val halfWidth = size.width * 0.16f

        pedestalPath.reset()
        pedestalPath.moveTo(center.x, baseY)
        pedestalPath.lineTo(center.x - halfWidth, midY)
        pedestalPath.lineTo(center.x, pedestalBottom)
        pedestalPath.lineTo(center.x + halfWidth, midY)
        pedestalPath.close()

        drawPath(
            path = pedestalPath,
            brush = Brush.verticalGradient(listOf(SparkColors.GlowPurple.copy(alpha = 0.6f), Color.Transparent))
        )
        drawPath(
            path = pedestalPath,
            color = SparkColors.NeonCyan.copy(alpha = 0.65f),
            style = Stroke(width = 1.dp.toPx())
        )
        drawLine(
            color = SparkColors.NeonCyan.copy(alpha = 0.4f),
            start = Offset(center.x, baseY),
            end = Offset(center.x, pedestalBottom)
        )

        drawCircle(
            brush = Brush.radialGradient(
                listOf(
                    SparkColors.NeonCyan.copy(alpha = 0.42f * pulseScale),
                    SparkColors.GlowPurple.copy(alpha = 0.08f),
                    Color.Transparent
                )
            ),
            radius = radius * 1.35f,
            center = center
        )
        drawCircle(
            brush = Brush.linearGradient(listOf(Color.White.copy(alpha = 0.8f), SparkColors.GlowPurple.copy(alpha = 0.3f))),
            radius = radius,
            center = center,
            style = Stroke(width = 2.dp.toPx())
        )

        withTransform({
            rotate(degrees = -25f + rotation, pivot = center)
            scale(scaleX = 1.0f, scaleY = 0.32f * pulseScale, pivot = center)
        }) {
            drawCircle(
                color = Color.White,
                radius = radius * 0.85f,
                center = center,
                style = Stroke(width = 1.8.dp.toPx())
            )
            drawCircle(
                brush = Brush.radialGradient(listOf(SparkColors.NeonCyan.copy(alpha = 0.7f), Color.Transparent)),
                radius = radius * 0.45f,
                center = center
            )
        }
    }
}
