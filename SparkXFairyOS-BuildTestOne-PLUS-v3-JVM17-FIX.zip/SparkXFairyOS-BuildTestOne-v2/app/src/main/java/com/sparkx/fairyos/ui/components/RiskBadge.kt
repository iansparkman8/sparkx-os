package com.sparkx.fairyos.ui.components

import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import com.sparkx.fairyos.domain.upgrade.UpgradeRiskLevel

@Composable
fun RiskBadge(risk: UpgradeRiskLevel) {
    Text(text = "Risk: ${risk.name}", color = Color.White)
}
