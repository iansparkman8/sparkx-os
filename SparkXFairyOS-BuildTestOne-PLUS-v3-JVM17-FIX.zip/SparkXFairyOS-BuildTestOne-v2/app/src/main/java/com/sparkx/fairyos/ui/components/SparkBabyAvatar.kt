package com.sparkx.fairyos.ui.components

import androidx.compose.animation.core.EaseInOutQuad
import androidx.compose.animation.core.EaseInOutSine
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.keyframes
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.defaultMinSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.withTransform
import androidx.compose.ui.unit.dp
import com.sparkx.fairyos.domain.FairyMood
import com.sparkx.fairyos.domain.upgrade.SparkColors
import kotlin.math.cos
import kotlin.math.min
import kotlin.math.sin

@Composable
fun SparkBabyAvatar(
    mood: FairyMood,
    modifier: Modifier = Modifier,
    isSpeaking: Boolean = false,
    isThinking: Boolean = false,
    isListening: Boolean = false
) {
    val transition = rememberInfiniteTransition(label = "SparkBabyLoops")
    val wingFlap by transition.animateFloat(
        initialValue = 0.25f,
        targetValue = 1.0f,
        animationSpec = infiniteRepeatable(
            animation = tween(520, easing = EaseInOutQuad),
            repeatMode = RepeatMode.Reverse
        ),
        label = "WingFlap"
    )
    val corePulse by transition.animateFloat(
        initialValue = 0.85f,
        targetValue = 1.15f,
        animationSpec = infiniteRepeatable(
            animation = tween(1400, easing = EaseInOutSine),
            repeatMode = RepeatMode.Reverse
        ),
        label = "CorePulse"
    )
    val bobbingOffset by transition.animateFloat(
        initialValue = -4f,
        targetValue = 4f,
        animationSpec = infiniteRepeatable(
            animation = tween(3000, easing = EaseInOutSine),
            repeatMode = RepeatMode.Reverse
        ),
        label = "Bobbing"
    )
    val orbitRotation by transition.animateFloat(
        initialValue = 0f,
        targetValue = 360f,
        animationSpec = infiniteRepeatable(
            animation = tween(7000, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "OrbitAngle"
    )
    val blinkState by transition.animateFloat(
        initialValue = 1f,
        targetValue = 0f,
        animationSpec = infiniteRepeatable(
            animation = keyframes {
                durationMillis = 7500
                1.0f at 0
                1.0f at 7200
                0.0f at 7350
                1.0f at 7500
            }
        ),
        label = "BlinkLoop"
    )

    val baseMoodColor = when (mood) {
        FairyMood.IDLE -> SparkColors.NeonCyan
        FairyMood.HAPPY -> SparkColors.VibrantMagenta
        FairyMood.THINKING -> SparkColors.GlowPurple
        FairyMood.LISTENING -> SparkColors.NeonCyan
        FairyMood.ALERT -> SparkColors.GoldEnergy
        FairyMood.SLEEPY -> SparkColors.SoftLavender
    }

    // Performance-conscious cached drawing paths.
    val leftWingPath = remember { Path() }
    val rightWingPath = remember { Path() }
    val torsoPath = remember { Path() }
    val crownPath = remember { Path() }
    val mouthPath = remember { Path() }

    Canvas(
        modifier = modifier.defaultMinSize(
            minWidth = 64.dp,
            minHeight = 64.dp
        )
    ) {
        val cx = size.width / 2f
        val cy = (size.height / 2f) + bobbingOffset.dp.toPx()
        if (cx <= 0f || cy <= 0f) return@Canvas

        val componentHeight = size.height
        val headRadius = componentHeight * 0.19f
        val headCenterY = cy - (componentHeight * 0.12f)
        val bodyTopY = headCenterY + headRadius - 3.dp.toPx()

        drawCircle(
            brush = Brush.radialGradient(
                listOf(baseMoodColor.copy(alpha = 0.25f * corePulse), Color.Transparent)
            ),
            radius = headRadius * 2.55f,
            center = Offset(cx, cy)
        )

        withTransform({
            scale(scaleX = wingFlap, scaleY = 1.0f, pivot = Offset(cx - 6.dp.toPx(), bodyTopY + 10.dp.toPx()))
        }) {
            leftWingPath.reset()
            leftWingPath.moveTo(cx - 4.dp.toPx(), bodyTopY + 8.dp.toPx())
            leftWingPath.cubicTo(
                cx - 45.dp.toPx(), bodyTopY - 35.dp.toPx(),
                cx - 68.dp.toPx(), bodyTopY + 5.dp.toPx(),
                cx - 4.dp.toPx(), bodyTopY + 32.dp.toPx()
            )
            leftWingPath.close()
            drawPath(leftWingPath, brush = Brush.linearGradient(listOf(baseMoodColor, Color.Transparent)), style = Stroke(width = 1.5.dp.toPx()))
            drawPath(leftWingPath, brush = Brush.radialGradient(listOf(baseMoodColor.copy(alpha = 0.12f), Color.Transparent)))

            for (i in 1..4) {
                val veinY = bodyTopY - 12.dp.toPx() + (i * 8.dp.toPx())
                drawLine(
                    color = baseMoodColor.copy(alpha = 0.15f),
                    start = Offset(cx - 6.dp.toPx(), bodyTopY + 12.dp.toPx()),
                    end = Offset(cx - 38.dp.toPx() + (i * 3.dp.toPx()), veinY),
                    strokeWidth = 1.dp.toPx()
                )
            }
        }

        withTransform({
            scale(scaleX = wingFlap, scaleY = 1.0f, pivot = Offset(cx + 6.dp.toPx(), bodyTopY + 10.dp.toPx()))
        }) {
            rightWingPath.reset()
            rightWingPath.moveTo(cx + 4.dp.toPx(), bodyTopY + 8.dp.toPx())
            rightWingPath.cubicTo(
                cx + 42.dp.toPx(), bodyTopY - 35.dp.toPx(),
                cx + 65.dp.toPx(), bodyTopY + 5.dp.toPx(),
                cx + 4.dp.toPx(), bodyTopY + 32.dp.toPx()
            )
            rightWingPath.close()
            drawPath(rightWingPath, brush = Brush.linearGradient(listOf(baseMoodColor, Color.Transparent)), style = Stroke(width = 1.5.dp.toPx()))
            drawPath(rightWingPath, brush = Brush.radialGradient(listOf(baseMoodColor.copy(alpha = 0.12f), Color.Transparent)))

            for (i in 1..4) {
                val veinY = bodyTopY - 12.dp.toPx() + (i * 8.dp.toPx())
                drawLine(
                    color = baseMoodColor.copy(alpha = 0.15f),
                    start = Offset(cx + 6.dp.toPx(), bodyTopY + 12.dp.toPx()),
                    end = Offset(cx + 38.dp.toPx() - (i * 3.dp.toPx()), veinY),
                    strokeWidth = 1.dp.toPx()
                )
            }
        }

        torsoPath.reset()
        torsoPath.moveTo(cx, bodyTopY)
        torsoPath.cubicTo(
            cx - 14.dp.toPx(), bodyTopY + 18.dp.toPx(),
            cx - 16.dp.toPx(), cy + (componentHeight * 0.22f),
            cx, cy + (componentHeight * 0.32f)
        )
        torsoPath.cubicTo(
            cx + 16.dp.toPx(), cy + (componentHeight * 0.22f),
            cx + 14.dp.toPx(), bodyTopY + 18.dp.toPx(),
            cx, bodyTopY
        )
        drawPath(torsoPath, brush = Brush.verticalGradient(listOf(Color.White, baseMoodColor.copy(alpha = 0.35f))))
        drawCircle(
            brush = Brush.radialGradient(listOf(Color.White, baseMoodColor.copy(alpha = 0.65f * corePulse), Color.Transparent)),
            radius = 12.dp.toPx() * corePulse,
            center = Offset(cx, bodyTopY + 14.dp.toPx())
        )

        drawCircle(
            brush = Brush.verticalGradient(listOf(Color.White, baseMoodColor.copy(alpha = 0.22f))),
            radius = headRadius,
            center = Offset(cx, headCenterY)
        )

        val eyeSpacingX = headRadius * 0.42f
        val eyeCenterY = headCenterY + 2.dp.toPx()
        val eyeRadius = headRadius * 0.18f
        val eyeScaleY = if (mood == FairyMood.SLEEPY) 0.3f else blinkState * when (mood) {
            FairyMood.HAPPY -> 1.3f
            FairyMood.THINKING -> 0.85f
            FairyMood.ALERT -> 1.2f
            FairyMood.IDLE,
            FairyMood.LISTENING,
            FairyMood.SLEEPY -> 1.0f
        }

        withTransform({ scale(scaleX = 1f, scaleY = eyeScaleY, pivot = Offset(cx - eyeSpacingX, eyeCenterY)) }) {
            drawCircle(color = baseMoodColor, radius = eyeRadius, center = Offset(cx - eyeSpacingX, eyeCenterY))
            drawCircle(color = Color.White, radius = 1.2.dp.toPx(), center = Offset(cx - eyeSpacingX - 0.8.dp.toPx(), eyeCenterY - 1.dp.toPx()))
        }
        withTransform({ scale(scaleX = 1f, scaleY = eyeScaleY, pivot = Offset(cx + eyeSpacingX, eyeCenterY)) }) {
            drawCircle(color = baseMoodColor, radius = eyeRadius, center = Offset(cx + eyeSpacingX, eyeCenterY))
            drawCircle(color = Color.White, radius = 1.2.dp.toPx(), center = Offset(cx + eyeSpacingX - 0.8.dp.toPx(), eyeCenterY - 1.dp.toPx()))
        }

        val mouthY = headCenterY + (headRadius * 0.42f)
        if (isSpeaking) {
            drawCircle(
                color = baseMoodColor.copy(alpha = 0.85f),
                radius = 2.5.dp.toPx() * corePulse,
                center = Offset(cx, mouthY),
                style = Stroke(width = 1.2.dp.toPx())
            )
        } else {
            mouthPath.reset()
            mouthPath.moveTo(cx - 3.5.dp.toPx(), mouthY)
            mouthPath.quadTo(cx, mouthY + 2.1.dp.toPx(), cx + 3.5.dp.toPx(), mouthY)
            drawPath(mouthPath, color = baseMoodColor.copy(alpha = 0.8f), style = Stroke(width = 1.5.dp.toPx()))
        }

        val crownBaseY = headCenterY - headRadius + 2.dp.toPx()
        crownPath.reset()
        crownPath.moveTo(cx, crownBaseY - 16.dp.toPx() * corePulse)
        crownPath.lineTo(cx - 5.dp.toPx(), crownBaseY - 3.dp.toPx())
        crownPath.lineTo(cx, crownBaseY)
        crownPath.lineTo(cx + 5.dp.toPx(), crownBaseY - 3.dp.toPx())
        crownPath.close()
        crownPath.moveTo(cx - 6.dp.toPx(), crownBaseY - 2.dp.toPx())
        crownPath.lineTo(cx - 13.dp.toPx(), crownBaseY - 10.dp.toPx() * corePulse)
        crownPath.lineTo(cx - 9.dp.toPx(), crownBaseY + 1.dp.toPx())
        crownPath.close()
        crownPath.moveTo(cx + 6.dp.toPx(), crownBaseY - 2.dp.toPx())
        crownPath.lineTo(cx + 13.dp.toPx(), crownBaseY - 10.dp.toPx() * corePulse)
        crownPath.lineTo(cx + 9.dp.toPx(), crownBaseY + 1.dp.toPx())
        crownPath.close()
        drawPath(crownPath, brush = Brush.verticalGradient(listOf(Color.White, SparkColors.GoldEnergy)))
        drawPath(crownPath, color = SparkColors.NeonCyan.copy(alpha = 0.65f), style = Stroke(width = 1.dp.toPx()))

        val maxRadius = min(size.width, size.height) * 0.42f
        val (particleColor, count, opacity) = when (mood) {
            FairyMood.HAPPY -> Triple(SparkColors.VibrantMagenta, 7, 0.95f)
            FairyMood.THINKING -> Triple(SparkColors.GlowPurple, 5, 0.8f)
            FairyMood.LISTENING -> Triple(SparkColors.NeonCyan, 6, 0.85f)
            FairyMood.ALERT -> Triple(SparkColors.GoldEnergy, 8, 0.95f)
            FairyMood.SLEEPY -> Triple(SparkColors.SoftLavender, 3, 0.35f)
            FairyMood.IDLE -> Triple(SparkColors.NeonCyan, 4, 0.65f)
        }
        val baseAngleRad = Math.toRadians(orbitRotation.toDouble())
        for (i in 0 until count) {
            val computedAngle = baseAngleRad + i * (2 * Math.PI / count)
            val yModifier = if (mood == FairyMood.THINKING || isThinking) 0.32f else if (isListening) 0.55f else 0.65f
            val particleX = cx + (maxRadius * cos(computedAngle)).toFloat()
            val particleY = cy + (maxRadius * sin(computedAngle)).toFloat() * yModifier
            drawCircle(
                color = particleColor.copy(alpha = opacity),
                radius = if (i % 2 == 0) 2.2.dp.toPx() else 1.2.dp.toPx(),
                center = Offset(particleX, particleY)
            )
            if (mood == FairyMood.HAPPY || mood == FairyMood.ALERT) {
                drawCircle(
                    color = SparkColors.GoldEnergy.copy(alpha = opacity * 0.25f),
                    radius = 4.5.dp.toPx(),
                    center = Offset(particleX, particleY)
                )
            }
        }
    }
}
