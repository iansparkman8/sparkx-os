package com.sparkx.fairyos.ui.components

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.sparkx.fairyos.domain.upgrade.SparkColors
import com.sparkx.fairyos.domain.upgrade.UpgradeItem

@Composable
fun UpgradeCard(
    item: UpgradeItem,
    onClick: () -> Unit
) {
    HoloGlassCard(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick),
        highlightColor = SparkColors.NeonCyan
    ) {
        Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
            Text(item.title, color = Color.White, fontWeight = FontWeight.Bold)
            Text(
                text = "${item.category} • ${item.status} • ${item.riskLevel}",
                color = SparkColors.NeonCyan,
                fontSize = 12.sp
            )
            Text(
                text = item.summary ?: "Spark Baby is safely studying this for you.",
                color = Color.White.copy(alpha = 0.7f),
                fontSize = 12.sp
            )
        }
    }
}
