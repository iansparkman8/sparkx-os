package com.sparkx.fairyos.ui.screens

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.EaseOutCubic
import androidx.compose.animation.core.tween
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.sparkx.fairyos.domain.FairyMood
import com.sparkx.fairyos.domain.upgrade.SparkColors
import com.sparkx.fairyos.ui.components.CommandInputBar
import com.sparkx.fairyos.ui.components.HoloBackground
import com.sparkx.fairyos.ui.components.HoloGlassCard
import com.sparkx.fairyos.ui.components.MagicOrb
import com.sparkx.fairyos.ui.components.QuickActionCard
import com.sparkx.fairyos.ui.components.SparkBabyAvatar

@Composable
fun SparkHomeScreen(
    userName: String = "Ian",
    fairyMood: FairyMood = FairyMood.IDLE,
    statusText: String = "Ready.",
    overlayReady: Boolean = false,
    micReady: Boolean = false,
    notificationReady: Boolean = false,
    onChatClick: () -> Unit = {},
    onTeachClick: () -> Unit = {},
    onReminderClick: () -> Unit = {},
    onMelodyClick: () -> Unit = {},
    onMemoriesClick: () -> Unit = {},
    onOverlayClick: () -> Unit = {},
    onMicPermissionClick: () -> Unit = {},
    onNotificationClick: () -> Unit = {},
    onCommandSubmit: (String) -> Unit = {},
    onMicClick: () -> Unit = {},
    onTypingStateShift: (Boolean) -> Unit = {}
) {
    val entranceAnim = remember { Animatable(0f) }
    LaunchedEffect(Unit) {
        entranceAnim.animateTo(1f, animationSpec = tween(1000, easing = EaseOutCubic))
    }

    HoloBackground(mood = fairyMood) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .statusBarsPadding()
                .navigationBarsPadding()
                .padding(24.dp)
                .alpha(entranceAnim.value)
                .scale(0.95f + entranceAnim.value * 0.05f),
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(top = 12.dp)
            ) {
                Text(
                    text = "Good evening, $userName.",
                    color = Color.White,
                    fontSize = 32.sp,
                    fontWeight = FontWeight.SemiBold,
                    style = MaterialTheme.typography.headlineLarge
                )
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = "What shall we create today?",
                    color = SparkColors.NeonCyan,
                    fontSize = 20.sp,
                    fontWeight = FontWeight.Medium,
                    style = MaterialTheme.typography.titleMedium
                )
            }

            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f),
                contentAlignment = Alignment.Center
            ) {
                Box(
                    modifier = Modifier
                        .align(Alignment.CenterStart)
                        .offset(x = (-8).dp, y = 48.dp)
                ) {
                    MagicOrb(orbSize = 100.dp)
                }
                Box(
                    modifier = Modifier
                        .align(Alignment.CenterEnd)
                        .offset(x = 12.dp)
                        .size(210.dp)
                ) {
                    SparkBabyAvatar(
                        mood = fairyMood,
                        modifier = Modifier.fillMaxSize(),
                        isListening = fairyMood == FairyMood.LISTENING,
                        isThinking = fairyMood == FairyMood.THINKING,
                        isSpeaking = fairyMood == FairyMood.HAPPY
                    )
                }
            }

            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 8.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    QuickActionCard("Chat", "✎", onChatClick, Modifier.weight(1f))
                    QuickActionCard("Teach & Grow", "✦", onTeachClick, Modifier.weight(1f))
                    QuickActionCard("Set Reminder", "▣", onReminderClick, Modifier.weight(1f))
                }
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    QuickActionCard("Float On", "◌", onOverlayClick, Modifier.weight(1f))
                    QuickActionCard("Play Melody", "♡", onMelodyClick, Modifier.weight(1f))
                    QuickActionCard("Explore Memories", "✧", onMemoriesClick, Modifier.weight(1f))
                }
                PermissionWizardCard(
                    overlayReady = overlayReady,
                    micReady = micReady,
                    notificationReady = notificationReady,
                    statusText = statusText,
                    onOverlayClick = onOverlayClick,
                    onMicClick = onMicPermissionClick,
                    onNotificationsClick = onNotificationClick
                )
                CommandInputBar(
                    onSubmit = onCommandSubmit,
                    onMicClick = onMicClick,
                    onTextChanged = { typedText -> onTypingStateShift(typedText.isNotEmpty()) }
                )
            }
        }
    }
}

@Composable
private fun PermissionWizardCard(
    overlayReady: Boolean,
    micReady: Boolean,
    notificationReady: Boolean,
    statusText: String,
    onOverlayClick: () -> Unit,
    onMicClick: () -> Unit,
    onNotificationsClick: () -> Unit
) {
    HoloGlassCard(
        modifier = Modifier.fillMaxWidth(),
        highlightColor = if (overlayReady && micReady) SparkColors.NeonCyan else SparkColors.GlowPurple
    ) {
        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text(
                text = statusText,
                color = Color.White.copy(alpha = 0.92f),
                fontSize = 12.sp,
                fontWeight = FontWeight.SemiBold
            )
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                WizardButton(
                    label = if (overlayReady) "Float Ready" else "Allow Float",
                    ready = overlayReady,
                    onClick = onOverlayClick,
                    modifier = Modifier.weight(1f)
                )
                WizardButton(
                    label = if (micReady) "Voice Ready" else "Allow Voice",
                    ready = micReady,
                    onClick = onMicClick,
                    modifier = Modifier.weight(1f)
                )
                WizardButton(
                    label = if (notificationReady) "Notice Ready" else "Allow Notice",
                    ready = notificationReady,
                    onClick = onNotificationsClick,
                    modifier = Modifier.weight(1f)
                )
            }
        }
    }
}

@Composable
private fun WizardButton(
    label: String,
    ready: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Button(
        onClick = onClick,
        modifier = modifier.height(38.dp),
        colors = ButtonDefaults.buttonColors(
            containerColor = if (ready) SparkColors.NeonCyan.copy(alpha = 0.82f) else SparkColors.GlowPurple.copy(alpha = 0.62f),
            contentColor = if (ready) Color.Black else Color.White
        ),
        contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 6.dp, vertical = 2.dp)
    ) {
        Text(
            text = label,
            fontSize = 10.sp,
            fontWeight = FontWeight.Bold,
            textAlign = TextAlign.Center,
            maxLines = 1
        )
    }
}
