package com.sparkx.fairyos.ui.screens.teach

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.sparkx.fairyos.domain.upgrade.SparkColors
import com.sparkx.fairyos.ui.components.HoloBackground
import com.sparkx.fairyos.ui.components.HoloGlassCard
import com.sparkx.fairyos.ui.components.SparkBabyAvatar
import com.sparkx.fairyos.ui.viewmodel.UpgradeLabViewModel

@Composable
fun TeachGrowScreen(
    viewModel: UpgradeLabViewModel,
    onBack: () -> Unit
) {
    val uiState by viewModel.uiState.collectAsState()
    val mood by viewModel.currentFairyMood.collectAsState()
    val context = LocalContext.current

    HoloBackground(mood = mood) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(16.dp)
        ) {
            if (uiState.selectedUpgrade != null) {
                val selected = uiState.selectedUpgrade!!
                UpgradeReviewScreen(
                    upgrade = selected,
                    avatarMood = mood,
                    onApprove = { viewModel.approveUpgrade(selected.id) },
                    onReject = { viewModel.rejectUpgrade(selected.id) },
                    onExport = { viewModel.copyApprovedUpgradesToClipboard(context) },
                    onDelete = { viewModel.deleteUpgrade(selected.id) },
                    onBack = { viewModel.selectUpgrade(null) }
                )
            } else {
                Column(modifier = Modifier.fillMaxSize()) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 16.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column {
                            Text(
                                text = "Teach Spark Baby",
                                color = Color.White,
                                fontSize = 26.sp,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = "Spark Baby is safely studying and organizing ideas for you.",
                                color = SparkColors.NeonCyan,
                                fontSize = 12.sp
                            )
                        }
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            TextButton(onClick = onBack) {
                                Text("Home", color = SparkColors.NeonCyan)
                            }
                            SparkBabyAvatar(mood = mood, modifier = Modifier.size(64.dp))
                        }
                    }
                    UpgradeLabScreen(viewModel = viewModel)
                }
            }

            uiState.message?.let { message ->
                HoloGlassCard(
                    modifier = Modifier
                        .align(Alignment.BottomCenter)
                        .padding(bottom = 18.dp),
                    highlightColor = SparkColors.NeonCyan
                ) {
                    Text(message, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                }
            }
        }
    }
}
