package com.sparkx.fairyos.ui.screens.teach

import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.ScrollableTabRow
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRowDefaults.tabIndicatorOffset
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.drawWithContent
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.sparkx.fairyos.domain.FairyMood
import com.sparkx.fairyos.domain.upgrade.SparkColors
import com.sparkx.fairyos.domain.upgrade.UpgradeStatus
import com.sparkx.fairyos.ui.components.HoloCodeBox
import com.sparkx.fairyos.ui.components.HoloGlassCard
import com.sparkx.fairyos.ui.components.HoloTextField
import com.sparkx.fairyos.ui.components.SparkBabyAvatar
import com.sparkx.fairyos.ui.components.UpgradeCard
import com.sparkx.fairyos.ui.viewmodel.UpgradeLabViewModel

@Composable
fun UpgradeLabScreen(viewModel: UpgradeLabViewModel) {
    var activeTab by remember { mutableStateOf(0) }
    val tabs = listOf("Share a Lesson", "Code Suggestion", "New Behavior", "Visual Polish Idea", "Saved Ideas")
    val uiState by viewModel.uiState.collectAsState()
    val context = LocalContext.current

    val indicatorTransition = rememberInfiniteTransition(label = "TabIndicatorShimmer")
    val pulseX by indicatorTransition.animateFloat(
        initialValue = -0.2f,
        targetValue = 1.2f,
        animationSpec = infiniteRepeatable(
            animation = tween(2000, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "PulseX"
    )

    Column(modifier = Modifier.fillMaxSize()) {
        ScrollableTabRow(
            selectedTabIndex = activeTab,
            containerColor = Color.Transparent,
            contentColor = SparkColors.NeonCyan,
            indicator = { tabPositions ->
                Box(
                    modifier = Modifier
                        .tabIndicatorOffset(tabPositions[activeTab])
                        .height(3.dp)
                        .drawWithContent {
                            drawRect(
                                brush = Brush.horizontalGradient(
                                    colors = listOf(SparkColors.GlowPurple, SparkColors.NeonCyan, SparkColors.GlowPurple),
                                    startX = size.width * (pulseX - 0.2f),
                                    endX = size.width * (pulseX + 0.2f)
                                )
                            )
                        }
                        .border(
                            width = 0.5.dp,
                            color = Color.White.copy(alpha = 0.3f),
                            shape = RoundedCornerShape(topStart = 3.dp, topEnd = 3.dp)
                        )
                )
            },
            divider = {}
        ) {
            tabs.forEachIndexed { index, label ->
                Tab(
                    selected = activeTab == index,
                    onClick = { activeTab = index },
                    text = { Text(label, fontWeight = FontWeight.Bold, fontSize = 12.sp) }
                )
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        Box(
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth()
        ) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                when (activeTab) {
                    0 -> LessonTab(viewModel)
                    1 -> CodeSuggestionTab(viewModel)
                    2 -> BehaviorTab(viewModel)
                    3 -> VisualIdeaTab(viewModel)
                    4 -> SavedIdeasTab(viewModel, context)
                }
            }
        }
    }
}

@Composable
private fun LessonTab(viewModel: UpgradeLabViewModel) {
    HoloGlassCard(highlightColor = SparkColors.NeonCyan) {
        var title by remember { mutableStateOf("") }
        var category by remember { mutableStateOf("") }
        var content by remember { mutableStateOf("") }
        var priority by remember { mutableStateOf("") }

        HoloTextField(title, { title = it }, "Lesson Title", leadingSymbol = "✎")
        Spacer(modifier = Modifier.height(10.dp))
        HoloTextField(category, { category = it }, "Category", leadingSymbol = "✦")
        Spacer(modifier = Modifier.height(10.dp))
        HoloTextField(content, { content = it }, "What should Spark Baby learn?", minLines = 3, leadingSymbol = "✎")
        Spacer(modifier = Modifier.height(10.dp))
        HoloTextField(priority, { priority = it }, "Importance", leadingSymbol = "✦")
        Spacer(modifier = Modifier.height(16.dp))
        Button(
            onClick = {
                viewModel.saveLessonUpgrade(title, category, content, priority)
                title = ""
                category = ""
                content = ""
                priority = ""
            },
            colors = ButtonDefaults.buttonColors(containerColor = SparkColors.NeonCyan),
            modifier = Modifier
                .fillMaxWidth()
                .height(48.dp)
        ) {
            Text("Save Lesson", color = Color.Black, fontWeight = FontWeight.Bold)
        }
    }
}

@Composable
private fun CodeSuggestionTab(viewModel: UpgradeLabViewModel) {
    HoloGlassCard(highlightColor = SparkColors.GlowPurple) {
        var title by remember { mutableStateOf("") }
        var file by remember { mutableStateOf("") }
        var lang by remember { mutableStateOf("") }
        var reason by remember { mutableStateOf("") }
        var code by remember { mutableStateOf("") }

        HoloTextField(title, { title = it }, "Update Title", leadingSymbol = "✎")
        Spacer(modifier = Modifier.height(10.dp))
        HoloTextField(file, { file = it }, "Target File", leadingSymbol = "✎")
        Spacer(modifier = Modifier.height(10.dp))
        HoloTextField(lang, { lang = it }, "Language", leadingSymbol = "✦")
        Spacer(modifier = Modifier.height(10.dp))
        HoloTextField(reason, { reason = it }, "Reason for Update", leadingSymbol = "✦")
        Spacer(modifier = Modifier.height(14.dp))
        HoloCodeBox(
            value = code,
            onValueChange = { code = it },
            placeholder = "Paste Kotlin, Compose, Gradle, XML, JSON, Markdown, or prompt updates here..."
        )
        Spacer(modifier = Modifier.height(16.dp))
        Button(
            onClick = {
                viewModel.saveCodeUpdate(title, file, lang, reason, code)
                title = ""
                file = ""
                lang = ""
                reason = ""
                code = ""
            },
            colors = ButtonDefaults.buttonColors(containerColor = SparkColors.GlowPurple),
            modifier = Modifier
                .fillMaxWidth()
                .height(48.dp)
        ) {
            Text("Save Upgrade for Spark Baby", color = Color.White, fontWeight = FontWeight.Bold)
        }
    }
}

@Composable
private fun BehaviorTab(viewModel: UpgradeLabViewModel) {
    HoloGlassCard(highlightColor = SparkColors.GoldEnergy) {
        var trigger by remember { mutableStateOf("") }
        var action by remember { mutableStateOf("") }
        var mood by remember { mutableStateOf("") }
        var voice by remember { mutableStateOf("") }

        HoloTextField(trigger, { trigger = it }, "When this happens...", leadingSymbol = "✦")
        Spacer(modifier = Modifier.height(10.dp))
        HoloTextField(action, { action = it }, "Spark Baby should...", leadingSymbol = "✎")
        Spacer(modifier = Modifier.height(10.dp))
        HoloTextField(mood, { mood = it }, "Mood change", leadingSymbol = "♡")
        Spacer(modifier = Modifier.height(10.dp))
        HoloTextField(voice, { voice = it }, "Voice response", leadingSymbol = "♡")
        Spacer(modifier = Modifier.height(16.dp))
        Button(
            onClick = {
                viewModel.saveBehaviorUpgrade(trigger, action, mood, voice)
                trigger = ""
                action = ""
                mood = ""
                voice = ""
            },
            colors = ButtonDefaults.buttonColors(containerColor = SparkColors.GoldEnergy),
            modifier = Modifier
                .fillMaxWidth()
                .height(48.dp)
        ) {
            Text("Save Behavior", color = Color.Black, fontWeight = FontWeight.Bold)
        }
    }
}

@Composable
private fun VisualIdeaTab(viewModel: UpgradeLabViewModel) {
    HoloGlassCard(highlightColor = SparkColors.VibrantMagenta) {
        var aspect by remember { mutableStateOf("") }
        var polish by remember { mutableStateOf("") }

        HoloTextField(aspect, { aspect = it }, "Avatar change", leadingSymbol = "✦")
        Spacer(modifier = Modifier.height(10.dp))
        HoloTextField(polish, { polish = it }, "UI Polish Note", minLines = 4, leadingSymbol = "✎")
        Spacer(modifier = Modifier.height(16.dp))
        Button(
            onClick = {
                viewModel.saveVisualUpgrade(aspect, polish)
                aspect = ""
                polish = ""
            },
            colors = ButtonDefaults.buttonColors(containerColor = SparkColors.VibrantMagenta),
            modifier = Modifier
                .fillMaxWidth()
                .height(48.dp)
        ) {
            Text("Save Visual Idea", color = Color.White, fontWeight = FontWeight.Bold)
        }
    }
}

@Composable
private fun SavedIdeasTab(viewModel: UpgradeLabViewModel, context: android.content.Context) {
    val uiState by viewModel.uiState.collectAsState()
    if (uiState.upgrades.isEmpty()) {
        HoloGlassCard(
            highlightColor = SparkColors.NeonCyan,
            modifier = Modifier
                .fillMaxWidth()
                .padding(top = 12.dp)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 24.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                SparkBabyAvatar(FairyMood.IDLE, Modifier.size(72.dp))
                Spacer(modifier = Modifier.height(16.dp))
                Text(
                    text = "Spark Baby hasn’t learned anything new yet. Share your first lesson, idea, or upgrade suggestion above.",
                    color = Color.White.copy(alpha = 0.75f),
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Medium,
                    textAlign = TextAlign.Center,
                    modifier = Modifier.padding(horizontal = 16.dp)
                )
            }
        }
    } else {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text("Saved Ideas", color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.Bold)
            Button(
                onClick = { viewModel.copyApprovedUpgradesToClipboard(context) },
                colors = ButtonDefaults.buttonColors(containerColor = SparkColors.NeonCyan)
            ) {
                Text("Copy Approved Ideas", color = Color.Black, fontSize = 11.sp, fontWeight = FontWeight.Bold)
            }
        }

        val groups = uiState.upgrades.groupBy { it.status }
        UpgradeStatus.values().forEach { status ->
            val items = groups[status].orEmpty()
            if (items.isNotEmpty()) {
                val label = when (status) {
                    UpgradeStatus.SAVED -> "Saved"
                    UpgradeStatus.NEEDS_REVIEW -> "Needs Review"
                    UpgradeStatus.APPROVED -> "Approved"
                    UpgradeStatus.REJECTED -> "Rejected"
                    UpgradeStatus.EXPORTED -> "Exported"
                }
                Text(
                    text = "$label (${items.size})",
                    color = SparkColors.GlowPurple,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Black,
                    modifier = Modifier.padding(top = 8.dp)
                )
                items.forEach { item ->
                    UpgradeCard(item = item) { viewModel.selectUpgrade(item) }
                }
            }
        }
    }
}
