package com.sparkx.fairyos.ui.screens.teach

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.sparkx.fairyos.domain.FairyMood
import com.sparkx.fairyos.domain.upgrade.SparkColors
import com.sparkx.fairyos.domain.upgrade.UpgradeItem
import com.sparkx.fairyos.domain.upgrade.UpgradeRiskLevel
import com.sparkx.fairyos.ui.components.HoloGlassCard
import com.sparkx.fairyos.ui.components.SparkBabyAvatar

@Composable
fun UpgradeReviewScreen(
    upgrade: UpgradeItem,
    avatarMood: FairyMood,
    onApprove: () -> Unit,
    onReject: () -> Unit,
    onExport: () -> Unit,
    onDelete: () -> Unit,
    onBack: () -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState()),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = onBack) {
                Text("‹", color = Color.White, fontSize = 30.sp, fontWeight = FontWeight.Bold)
            }
            Text("Review Upgrade", color = SparkColors.NeonCyan, fontSize = 14.sp, fontWeight = FontWeight.Bold)
            SparkBabyAvatar(avatarMood, Modifier.size(52.dp))
        }

        if (upgrade.riskLevel == UpgradeRiskLevel.HIGH || !upgrade.warnings.isNullOrBlank()) {
            HoloGlassCard(highlightColor = SparkColors.GoldEnergy) {
                Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Text(
                        text = "Spark Baby flagged this for your review",
                        color = SparkColors.GoldEnergy,
                        fontWeight = FontWeight.Black
                    )
                    Text(
                        text = "This upgrade may touch sensitive areas. Review it carefully before approving.",
                        color = Color.White,
                        fontSize = 12.sp
                    )
                }
            }
        }

        HoloGlassCard(
            highlightColor = if (upgrade.riskLevel == UpgradeRiskLevel.HIGH) {
                SparkColors.VibrantMagenta
            } else {
                SparkColors.NeonCyan
            }
        ) {
            Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Text("Upgrade: ${upgrade.title}", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                Text("Status: ${upgrade.status.name}", color = SparkColors.GlowPurple, fontSize = 12.sp)
                Text("Target File: ${upgrade.targetFile ?: "No target file chosen"}", color = Color.White.copy(alpha = 0.65f), fontSize = 12.sp)
                Text("Language: ${upgrade.language ?: "Not detected yet"}", color = Color.White.copy(alpha = 0.65f), fontSize = 12.sp)
            }
        }

        Text("Spark Baby’s Notes:", color = Color.White, fontWeight = FontWeight.Bold)
        Text(upgrade.summary ?: "Spark Baby is safely studying this for you.", color = SparkColors.NeonCyan)
        Text("Upgrade Content:", color = Color.White, fontWeight = FontWeight.Bold)
        HoloGlassCard(highlightColor = SparkColors.GlowPurple) {
            Text(upgrade.content, color = SparkColors.NeonCyan, fontSize = 12.sp)
        }

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Button(
                onClick = onApprove,
                colors = ButtonDefaults.buttonColors(containerColor = SparkColors.NeonCyan),
                modifier = Modifier.weight(1f)
            ) {
                Text("Approve", color = Color.Black)
            }
            Button(onClick = onReject, modifier = Modifier.weight(1f)) {
                Text("Reject")
            }
        }
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Button(
                onClick = onExport,
                colors = ButtonDefaults.buttonColors(containerColor = SparkColors.GlowPurple),
                modifier = Modifier.weight(1f)
            ) {
                Text("Copy Export")
            }
            Button(
                onClick = onDelete,
                colors = ButtonDefaults.buttonColors(containerColor = SparkColors.VibrantMagenta),
                modifier = Modifier.weight(1f)
            ) {
                Text("Delete Upgrade")
            }
        }
        Spacer(modifier = Modifier.height(24.dp))
    }
}
