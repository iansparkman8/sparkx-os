package com.sparkx.fairyos.ui.viewmodel

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import androidx.lifecycle.ViewModel
import com.sparkx.fairyos.domain.FairyMood
import com.sparkx.fairyos.domain.upgrade.UpgradeCategory
import com.sparkx.fairyos.domain.upgrade.UpgradeItem
import com.sparkx.fairyos.domain.upgrade.UpgradeRiskLevel
import com.sparkx.fairyos.domain.upgrade.UpgradeStatus
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.update

data class UpgradeLabUiState(
    val upgrades: List<UpgradeItem> = emptyList(),
    val selectedUpgrade: UpgradeItem? = null,
    val message: String? = null
)

class UpgradeLabViewModel : ViewModel() {
    private val _uiState = MutableStateFlow(UpgradeLabUiState())
    val uiState: StateFlow<UpgradeLabUiState> = _uiState

    private val _currentFairyMood = MutableStateFlow(FairyMood.IDLE)
    val currentFairyMood: StateFlow<FairyMood> = _currentFairyMood

    private var nextId = 1L

    private fun save(
        title: String,
        content: String,
        category: UpgradeCategory,
        targetFile: String? = null,
        language: String? = null,
        reason: String? = null
    ) {
        val risk = analyzeRisk(content)
        val item = UpgradeItem(
            id = nextId++,
            title = title.ifBlank { "Untitled Idea" },
            targetFile = targetFile,
            language = language,
            content = content,
            category = category,
            reason = reason,
            riskLevel = risk,
            status = UpgradeStatus.NEEDS_REVIEW,
            summary = "Spark Baby saved this idea for safe review.",
            warnings = if (risk == UpgradeRiskLevel.HIGH) {
                "Spark Baby recommends reviewing this carefully."
            } else {
                null
            }
        )
        _uiState.update { state ->
            state.copy(
                upgrades = listOf(item) + state.upgrades,
                message = "Saved for Spark Baby to study."
            )
        }
        _currentFairyMood.value = if (risk == UpgradeRiskLevel.HIGH) FairyMood.ALERT else FairyMood.HAPPY
    }

    private fun analyzeRisk(text: String): UpgradeRiskLevel {
        val lower = text.lowercase()
        return when {
            listOf(
                "runtime.exec",
                "processbuilder",
                "dexclassloader",
                "pathclassloader",
                "steal",
                "password",
                "token",
                "exfiltrate",
                "keylogger",
                "upload private data"
            ).any { it in lower } -> UpgradeRiskLevel.HIGH

            listOf(
                "accessibilityservice",
                "record_audio",
                "system_alert_window",
                "network upload",
                "foreground_service"
            ).any { it in lower } -> UpgradeRiskLevel.MEDIUM

            else -> UpgradeRiskLevel.LOW
        }
    }

    fun saveLessonUpgrade(title: String, category: String, content: String, priority: String) {
        val body = listOf(
            "Category: $category",
            "Importance: $priority",
            "Lesson: $content"
        ).joinToString(separator = "\n")
        save(title = title, content = body, category = UpgradeCategory.LESSON)
    }

    fun saveCodeUpdate(title: String, file: String, lang: String, reason: String, code: String) {
        save(
            title = title,
            content = code,
            category = UpgradeCategory.CODE_UPDATE,
            targetFile = file.ifBlank { null },
            language = lang.ifBlank { null },
            reason = reason.ifBlank { null }
        )
    }

    fun saveBehaviorUpgrade(trigger: String, action: String, mood: String, voice: String) {
        val body = listOf(
            "When: $trigger",
            "Spark Baby should: $action",
            "Mood: $mood",
            "Voice: $voice"
        ).joinToString(separator = "\n")
        save(title = "Behavior: ${trigger.ifBlank { "New behavior" }}", content = body, category = UpgradeCategory.BEHAVIOR_UPGRADE)
    }

    fun saveVisualUpgrade(aspect: String, polish: String) {
        save(title = "Visual: ${aspect.ifBlank { "New visual idea" }}", content = polish, category = UpgradeCategory.VISUAL_UPGRADE)
    }

    fun selectUpgrade(item: UpgradeItem?) {
        _uiState.update { it.copy(selectedUpgrade = item) }
    }

    fun approveUpgrade(id: Long) {
        updateStatus(id, UpgradeStatus.APPROVED)
        _currentFairyMood.value = FairyMood.HAPPY
    }

    fun rejectUpgrade(id: Long) {
        updateStatus(id, UpgradeStatus.REJECTED)
        _currentFairyMood.value = FairyMood.IDLE
    }

    fun deleteUpgrade(id: Long) {
        _uiState.update { state ->
            state.copy(
                upgrades = state.upgrades.filterNot { it.id == id },
                selectedUpgrade = null,
                message = "Deleted upgrade idea."
            )
        }
    }

    private fun updateStatus(id: Long, status: UpgradeStatus) {
        _uiState.update { state ->
            val updatedUpgrades = state.upgrades.map { item ->
                if (item.id == id) item.copy(status = status) else item
            }
            state.copy(
                upgrades = updatedUpgrades,
                selectedUpgrade = state.selectedUpgrade?.let { selected ->
                    if (selected.id == id) selected.copy(status = status) else selected
                },
                message = "Updated idea status."
            )
        }
    }

    fun copyApprovedUpgradesToClipboard(context: Context) {
        val approved = _uiState.value.upgrades.filter { it.status == UpgradeStatus.APPROVED }
        val export = if (approved.isEmpty()) {
            "No approved Spark Baby ideas yet."
        } else {
            approved.joinToString(separator = "\n\n---\n\n") { item ->
                "# ${item.title}\nStatus: ${item.status}\nRisk: ${item.riskLevel}\n\n${item.content}"
            }
        }
        val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        clipboard.setPrimaryClip(ClipData.newPlainText("SparkX Fairy OS Approved Ideas", export))
        _uiState.update { it.copy(message = "Copied approved ideas.") }
        _currentFairyMood.value = FairyMood.HAPPY
    }
}
