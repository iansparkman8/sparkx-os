# Build/Test One Plus QA

## Build checks

Run:

```bash
bash scripts/preflight_static_check.sh .
gradle :app:compileDebugKotlin --no-daemon --stacktrace
gradle :app:assembleDebug --no-daemon --stacktrace
```

## Install checks

1. Install `app-debug.apk` on a real Android phone.
2. Open the app.
3. Confirm the home screen appears without crashing.
4. Confirm Spark Baby animates.
5. Tap **Allow Notice** and approve if Android asks.
6. Tap **Allow Voice** and approve if Android asks.
7. Tap **Allow Float**, enable overlay permission, return to the app.
8. Tap **Float On**.
9. Confirm a Spark Baby bubble appears above the launcher or another app.
10. Drag the bubble.
11. Tap the bubble to expand/collapse.
12. Pull notification shade and test **Open** and **Hide**.
13. Reopen app and tap the command bar mic/heart.
14. Say “float” or “teach Spark Baby”.
15. Confirm the app responds to speech.
16. Open **Teach & Grow**.
17. Save a lesson.
18. Review, approve, reject, copy export, and delete.

## Expected non-final areas

- Melody button changes mood only; real audio engine is next.
- Reminder button stages notification permission only; real reminder scheduler is next.
- Teach & Grow ideas are in-memory for build/test one; persistent storage is next.
- The overlay is a custom Canvas fairy, not a full 3D model yet.
