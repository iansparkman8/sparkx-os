# Visual References Guide

Use these as visual targets, not code requirements.

## Primary target references

- `942.jpg` — portrait home-screen layout target
- `949.jpg` — landscape hero layout target
- `951.jpg` — Spark Baby mood sheet target
- `952.jpg` — Upgrade Lab visual direction
- `940.jpg` — icon/avatar polish target
- `953.jpg`, `954.jpg`, `955.jpg` — Phase 2 floating overlay vision

## Secondary style references

- `941.jpg` — earlier fairy sheet, useful for wing and particle ideas
- `510.webp`, `512.webp`, `513.jpg`, `656.jpg` — contrast references only; do not copy directly as default app style

## Visual north star

Spark Baby should feel like a premium holographic creature living inside the phone: magical, warm, safe, and alive.
