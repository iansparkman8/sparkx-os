#!/usr/bin/env bash
set -euo pipefail

ROOT="${1:-.}"
SRC="$ROOT/app/src/main/java"

if [[ ! -d "$SRC" ]]; then
  echo "ERROR: Kotlin source directory not found: $SRC" >&2
  exit 1
fi

fail() {
  echo "ERROR: $1" >&2
  exit 1
}

# These checks are intentionally strict for the build/test-one package.
if grep -R "androidx.compose.material.icons\|Icons.Default\|Icons.Filled" -n "$SRC" >/tmp/sparkx_icon_hits.txt 2>/dev/null; then
  cat /tmp/sparkx_icon_hits.txt
  fail "Material icon dependency detected. This package uses text/symbol icons to avoid icon-set build failures."
fi

if grep -R "FairyMood.GlowPurple\|[0-9][0-9]*dp\.toPx\|Runtime\.exec\|ProcessBuilder\|DexClassLoader\|PathClassLoader" -n "$SRC" >/tmp/sparkx_forbidden_hits.txt 2>/dev/null; then
  cat /tmp/sparkx_forbidden_hits.txt
  fail "Forbidden compile/security pattern detected."
fi

if grep -R "fun MagicOrb(.*size:" -n "$SRC" >/tmp/sparkx_orb_hits.txt 2>/dev/null; then
  cat /tmp/sparkx_orb_hits.txt
  fail "MagicOrb must not use a parameter named size. Use orbSize."
fi

if grep -R "HoloBackground([^)]*FairyMood" -n "$SRC" >/tmp/sparkx_holo_hits.txt 2>/dev/null; then
  cat /tmp/sparkx_holo_hits.txt
  fail "Potential positional HoloBackground call detected. Use named argument: HoloBackground(mood = ...)."
fi

python3 - <<'PY'
from pathlib import Path
root = Path('app/src/main/java')
if not root.exists():
    raise SystemExit(0)
for p in root.rglob('*.kt'):
    text = p.read_text()
    in_string = False
    escaped = False
    for idx, ch in enumerate(text):
        if escaped:
            escaped = False
            continue
        if ch == '\\':
            escaped = True
            continue
        if ch == '"':
            in_string = not in_string
            continue
        if ch == '\n' and in_string:
            raise SystemExit(f"ERROR: possible raw newline inside Kotlin string in {p}:{text.count(chr(10), 0, idx)+1}")
PY

echo "SparkX preflight static checks passed."
